<?php
include "incl/messages/deleteGJMessages.php";
?>